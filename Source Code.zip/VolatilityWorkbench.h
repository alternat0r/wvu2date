﻿// Volatility Workbecnch software
// Main header file
// Copyright Wrensoft 2018
// www.passmark.com
//
// Volatility Workbecnch is free software; you can redistribute it and / or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Volatility Workbecnch is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Volatility.If not, see <http://www.gnu.org/licenses/>.

#ifndef VOLATILITY_WORKBENCH_H
#define VOLATILITY_WORKBENCH_H

#include "resource.h"

#define	COMPANY_NAME				L"PassMark"
#define	COMPANY_NAME_SHORT			L"PassMark"

#define PROGRAM_NAME				L"Volatility Workbench"
#define PROGRAM_VERSION				L"V3.0"
#define PROGRAM_BUILD				L"1002"
#define	PASSMARK_WEBSITE			L"http://www.passmark.com"
#define VOLATILITY_EXE				L"vol.exe"
#define VOLATILITY_VER				L"3 1.1.0-beta.1"
#define	VOLATILITY_WEBSITE			L"http://www.volatilityfoundation.org"

#define MIN_WINDOW_WIDTH			1090	//Minimum dialog width
#define MIN_WINDOW_HEIGHT			700		//Minimum dialog height
#define WEBCTRL_OFFSET_X			15		//X Offset of web control in the dialog
#define WEBCTRL_OFFSET_Y			210		//Y Offset of web cotnrol int the dialog
#define WEBCTRL_WIDTHOFFSET_X		30		//Offset for width of web control 
#define WEBCTRL_HEIGHTOFFSET_X		260		//Offset for height of web control 

#define MAXDIRNAME					300
#define	MAXFILENAME					200
#define	MAXPARAMETERSLEN			500
#define MAX_SEARCH_STRING_LEN		300		//maximum search string lenght
#define MAX_ENVIRONMENT_STRING_LEN	2024
#define MAX_URL_LEN					2048
#define MAX_HEADER_TEXT_LEN			1024
#define MAX_RESULT_BUFF_LEN			1048576
#define	INIT_HTML_BUFF_LEN			1024
#define OK							true
#define NOK							false
#define NUM_OF_FILES				150

#define	NUM_SCRIPTS					20


//Window resizing modes
#define		RS_MOVE			0
#define		RS_RESIZE		1
#define		RS_MOVE_DOWN	2
#define		RS_MOVE_ACROSS	3
//#define		RS_RESIZE_HALFY	4
#define		RS_MOVE_ACROSS_SIZE_DOWN	5
#define		RS_MOVE_DOWN_SIZE_ACROSS	6
#define		RS_MOVE_DOWN_AND_ACROSS	7
#define		RS_SIZE_ACROSS	8

//Image positioning
#define		IMAGE_OFFSET	0
#define		IMAGE_HEIGHT	102

#define		NUM_PLATFORMS			3

//#define		NUM_USER_COMMANDS	   1
//#define		NUM_WIN_COMMANDS	   34
//#define		NUM_MAC_COMMANDS	   14
//#define		NUM_LIN_COMMANDS	   10

#define     TOT_COMMANDS           59
#define     TOT_SCRIPTS				1
#define		NUM_PROFILES		   200
#define     NUM_BASE_PROFILES      54
#define		MAX_NUM_PARAM		   10
#define		MAX_KDBG_ADDR_LEN	   20
#define		MAX_COM_STR_LEN	       10
#define		MAX_NUM_PROCESS		   500
#define		MAX_PROCESS_LEN		   50

#define		MAX_NUM_VALUEITEMS		2000
#define		MAX_VALUE_LEN			50

#define		CHECKTYPE_NOCHECKBOX	0
#define		CHECKTYPE_CHECKBOX		1
#define		CHECKTYPE_RADIOBUTTON	2

#define		VALUETYPE_NOVALUE		0
#define		VALUETYPE_EDITBOX		1
#define		VALUETYPE_COMBOBOX		2

#define		VALIDATION_DISABLED		0
#define		VALIDATION_DIGIT		1
#define		VALIDATION_HEXADDRESS	2
#define		VALIDATION_REGEX		3
#define		VALIDATION_DIR			4

typedef enum CURSOR_TYPE
{
	ARROW = 0,
	WAIT
};

typedef struct ParamValue_t
{
	int			NumItems;
	wchar_t		Name[MAX_NUM_VALUEITEMS][MAX_VALUE_LEN];
	wchar_t		Value[MAX_NUM_VALUEITEMS][MAX_VALUE_LEN];
};

struct VOLATILITY_PARAM_TYPEDEF
{
	wchar_t			*pszLabelText;
	wchar_t			*pszParam;
	bool			bPluginParam;
	char			CheckType;
	int				nCheckDlgID;
	bool			bChecked;
	char			ValueType;
	int				nValueDlgID;
	ParamValue_t	*ValueList;
	char			ValidationType;
};

#define CMD_PARAM (_LABELTXT, _PARAM, _CHECKBOXTYPE, _CHECKID, _CHECKED, _VALUETYPE, _VALUEID) {_LABELTXT, _PARAM, _CHECKBOXTYPE, _CHECKID, _CHECKED, _VALUETYPE, _VALUEID}
#define NOPARAM		{L"", L"", CHECKTYPE_NOCHECKBOX, 0, 0, VALUETYPE_NOVALUE, 0}

typedef struct VOLATILITY_CMD_TYPEDEF
{
	wchar_t		*pszPlatform;
	wchar_t		*pszCommand;
	wchar_t		*pszDescription;
	int			nParams;
	VOLATILITY_PARAM_TYPEDEF	params[MAX_NUM_PARAM];
};

#define VOLATILITY_COMMAND(_CMD, _DESCRIPTION, _NUMPARAM, _PARAM1, _PARAM2, _PARAM3, _PARAM4, _PARAM5, _PARAM6, _PARAM7, _PARAM8, _PARAM9, _PARAM10)	{ _CMD, _DESCRIPTION, _NUMPARAM, { _PARAM1, _PARAM2, _PARAM3, _PARAM4, _PARAM5, _PARAM6, _PARAM7, _PARAM8, _PARAM9, _PARAM10 } }

typedef struct VOLATILITY_PROFILE_TYPEDEF
{
	wchar_t *Profile;
	wchar_t *Description;
};

#define VOLATILITY_PROFILE(PROFILE, DESCRIPTION)	{PROFILE, DESCRIPTION}

typedef struct CONFIG
{
	wchar_t		Profile[MAX_PROFILE_LEN];
	wchar_t		KDBG_Addr[MAX_KDBG_ADDR_LEN];
	int			ProcessCount;
	wchar_t		ProcessName[MAX_NUM_PROCESS][MAX_PROCESS_LEN];
	wchar_t		PID[MAX_NUM_PROCESS][MAX_PROCESS_LEN];
};

// Global variables
#if defined (MAIN_MODULE)
	HWND				ghMainWnd;					//Main window
	char				lastURL[MAX_URL_LEN];		//last URL that was clicked and needs processing
	wchar_t				fullpath[MAXFILENAME + MAXDIRNAME] = { L'\0' };		//Work area, temp var
	wchar_t				RunDirName[MAXDIRNAME];
	wchar_t				szDefaultLogName[MAXFILENAME] = L"\\VolatilityWorkbenchLog.txt";	//Contains the default Log file name
	wchar_t				gFileName[MAXFILENAME + MAXDIRNAME];
	unsigned int		gControlsList[] = { IDC_CHECK1, IDC_CHECK2, IDC_CHECK3, IDC_CHECK4, IDC_CHECK5, IDC_CHECK6, IDC_CHECK7, IDC_CHECK8, IDC_CHECK9, IDC_CHECK10, IDC_RADIO1, IDC_RADIO2, IDC_RADIO3, IDC_RADIO4, IDC_RADIO5, IDC_RADIO6, IDC_RADIO7, IDC_EDIT1, IDC_EDIT2, IDC_EDIT3, IDC_EDIT4, IDC_EDIT5, IDC_EDIT6, IDC_EDIT7, IDC_DROPDOWN1, IDC_DROPDOWN2, IDC_DROPDOWN3, IDC_DROPDOWN4, IDC_DROPDOWN5, IDC_DROPDOWN6, IDC_DROPDOWN7, IDC_GROUP1, IDC_GROUP2, IDC_GROUP3, IDC_GROUP4, IDC_GROUP5, IDC_GROUP6, IDC_GROUP7, IDC_GROUP8};
	ParamValue_t		gProcessList;

	VOLATILITY_CMD_TYPEDEF		gCommands[TOT_COMMANDS] =
	{
		{ L"All", L"user.script", L"User script", 1,
			{
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_CHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.callbacks.Callbacks", L"Print system-wide notification routines", 0	},

		{ L"Windows", L"windows.cmdline.CmdLine", L"Lists process command line arguments", 1,
			{
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.dlldump.DllDump", L"Dumps process memory ranges as DLLs", 3,
			{
				{ L"Dump Folder Name", L"--output-dir", FALSE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_CHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DIR },
				{ L"Process virtual memory", L"--address", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_HEXADDRESS },
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN3, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.dlllist.DllList", L"Lists the loaded modules in a particular windows memory image", 1,
			{
				{ L"Process ID", L"--pid ", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.driverirp.DriverIrp", L"List IRPs for drivers in a particular windows memory image", 0 },

		{ L"Windows", L"windows.driverscan.DriverScan", L"Scans for drivers present in a particular windows	memory image", 0 },

		{ L"Windows", L"windows.filescan.FileScan", L"Scans for file objects present in a particular windows memory image", 0 },

		{ L"Windows", L"windows.handles.Handles", L"Lists process open handles", 1,
			{
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.info.Info", L"Show OS & kernel details of the memory sample being analyzed.", 0 },

		{ L"Windows", L"windows.malfind.Malfind", L"Find hidden and injected code", 1,
			{
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN1, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.moddump.ModDump", L"Dumps kernel modules", 0 },

		{ L"Windows", L"windows.modscan.ModScan", L"Pool scanner for kernel modules", 0 },

		{ L"Windows", L"windows.modules.Modules", L"Print list of loaded modules", 0 },

		{ L"Windows", L"windows.mutantscan.MutantScan", L"Scans for mutexes present in a particular windows memory image", 0 },

		{ L"Windows", L"windows.poolscanner.PoolScanner", L"A generic pool scanner plugin", 0 },

		{ L"Windows", L"windows.procdump.ProcDump", L"Dumps process executable images", 2,
			{
				{ L"Dump Folder Name", L"--output-dir", FALSE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_CHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DIR },
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.pslist.PsList", L"Lists the processes present in a particular windows memory image", 2,
			{
				{ L"Display physical offsets", L"--physical", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_RADIOBUTTON, IDC_RADIO2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.psscan.PsScan", L"Scans for processes present in a particular windows memory image", 0 },

		{ L"Windows", L"windows.pstree.PsTree", L"Plugin for listing processes in a tree based on their parent process ID", 2,
			{
				{ L"Display physical offsets", L"--physical", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_RADIOBUTTON, IDC_RADIO2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2,&gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.registry.certificates.Certificates", L"Lists the certificates in the registry's Certificate Store", 0 },

		{ L"Windows", L"windows.registry.hivelist.HiveList", L"Lists the registry hives present in a particular	memory image", 1,
			{
				{ L"Filter", L"--filter", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.registry.hivescan.HiveScan", L"Scans for registry hives present in a particular windows memory image", 0 },

		{ L"Windows", L"windows.registry.printkey.PrintKey", L"Lists the registry keys under a hive or specific key value", 3,
			{
				{ L"Hive Offset", L"--offset", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_HEXADDRESS },
				{ L"Key to start from", L"--key", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
				{ L"Recurses through keys", L"--recurse", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_NOVALUE, 0, NULL, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.registry.userassist.UserAssist", L"Print userassist registry keys and information", 1,
			{
				{ L"Hive Offset", L"--offset", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_HEXADDRESS }
			}
		},

		{ L"Windows", L"windows.ssdt.SSDT", L"Lists the system call table", 0 },

		{ L"Windows", L"windows.statistics.Statistics", L"Statistics", 0 },

		{ L"Windows", L"windows.strings.Strings", L"Reads output from the strings command and indicates	which process(es) each string belongs to", 1,
			{
				{ L"Strings file", L"--strings-file", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED }
			}
		},

		{ L"Windows", L"windows.svcscan.SvcScan", L"Scans for windows services", 0 },

		{ L"Windows", L"windows.symlinkscan.SymlinkScan", L"Scans for links present in a particular windows memory image", 0 },

		{ L"Windows", L"windows.vaddump.VadDump", L"Dumps process memory ranges", 2,
			{
				{ L"Dump Folder Name", L"--output-dir", FALSE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_CHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DIR },
				{ L"Process virtual address", L"--address", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_HEXADDRESS },
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN3, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.vadinfo.VadInfo", L"Lists process memory ranges", 2,
			{
			{ L"Process virtual address", L"--address", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_HEXADDRESS },
			{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN2, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.vadyarascan.VadYaraScan", L"Scans all the Virtual Address Descriptor memory maps using yara", 5,
			{
				{ L"Match wide strings", L"--wide", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK1, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT1, NULL, VALIDATION_DISABLED },
				{ L"Yara rules (string)", L"--yara-rules", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK2, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT2, NULL, VALIDATION_DISABLED },
				{ L"Yara rules (file)", L"--yara-file", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK3, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT3, NULL, VALIDATION_DISABLED },
				{ L"Maximum size", L"--max-size", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK4, BST_UNCHECKED, VALUETYPE_EDITBOX, IDC_EDIT4, NULL, VALIDATION_DIGIT },
				{ L"Process ID", L"--pid", TRUE, CHECKTYPE_CHECKBOX, IDC_CHECK5, BST_UNCHECKED, VALUETYPE_COMBOBOX, IDC_DROPDOWN5, &gProcessList, VALIDATION_DISABLED },
			}
		},

		{ L"Windows", L"windows.verinfo.VerInfo", L"Lists version information from PE files", 0 },

		{ L"Windows", L"windows.virtmap.VirtMap", L"Lists virtual mapped sections", 0 },

		{ L"Mac", L"mac.bash.Bash", L"Recovers bash command history from memory", 0 },

		{ L"Mac", L"mac.check_syscall.Check_syscall", L"Check system call table for hooks", 0 },

		{ L"Mac", L"mac.check_sysctl.Check_sysctl", L"Check sysctl handlers for hooks", 0 },

		{ L"Mac", L"mac.check_trap_table.Check_trap_table", L"Check mach trap table for hooks", 0 },

		{ L"Mac", L"mac.ifconfig.Ifconfig", L"Lists loaded kernel modules", 0 },

		{ L"Mac", L"mac.lsmod.Lsmod", L"Lists loaded kernel modules", 0 },

		{ L"Mac", L"mac.lsof.lsof", L"Lists all open file descriptors for all processes", 0 },

		{ L"Mac", L"mac.netstat.Netstat", L"Lists all network connections for all processes", 0 },

		{ L"Mac", L"mac.proc_maps.Maps", L"Lists process memory ranges that potentially contain	injected code", 0 },

		{ L"Mac", L"mac.psaux.Psaux", L"Recovers program command line arguments", 0 },

		{ L"Mac", L"mac.pslist.PsList", L"Lists the processes present in a particular mac memory image", 0 },

		{ L"Mac", L"mac.pstree.PsTree", L"Plugin for listing processes in a tree based on their	parent process ID", 0 },

		{ L"Mac", L"mac.tasks.Tasks", L"Lists the processes present in a particular mac memory image", 0 },

		{ L"Mac", L"mac.trustedbsd.Check_syscall", L"Check system call table for hooks", 0 },
		
		{ L"Linux", L"linux.bash.Bash", L"Recovers bash command history from memory", 0 },

		{ L"Linux", L"linux.check_afinfo.Check_afinfo", L"Verifies the operation function pointers of network	protocols", 0 },

		{ L"Linux", L"linux.check_syscall.Check_syscall", L"Check system call table for hooks", 0 },

		{ L"Linux", L"linux.elfs.Elfs", L"Lists all memory mapped ELF files for all processes", 0 },

		{ L"Linux", L"linux.lsmod.Lsmod", L"Lists loaded kernel modules", 0 },

		{ L"Linux", L"linux.lsof.Lsof", L"Lists all memory maps for all processes", 0 },

		{ L"Linux", L"linux.malfind.Malfind", L"Lists process memory ranges that potentially contain injected code", 0 },

		{ L"Linux", L"linux.proc.Maps", L"Lists the processes present in a particular linux memory image", 0 },
		
		{ L"Linux", L"linux.pslist.PsList", L"Lists all memory maps for all processes", 0 },

		{ L"Linux", L"linux.pstree.PsTree", L"Plugin for listing processes in a tree based on their parent process ID", 0 },

	};


	wchar_t		*gPlatforms[NUM_PLATFORMS] =
	{
		L"Windows",
		L"Linux",
		L"Mac"
	};

	wchar_t		gPlatform[10];

	PROCESS_INFORMATION gProcessInfo;
	bool		gCommandRunning = false;
	//wchar_t		gProfile[MAX_PROFILE_LEN];
	wchar_t		gKDBG_Addr[MAX_KDBG_ADDR_LEN];

	CRITICAL_SECTION	LogCritSection;

	wchar_t		gStrProgress[100] = { L'\0' };

	int			gNumScript = 0;
	wchar_t		gScriptFileNames[NUM_SCRIPTS][MAXFILENAME + MAXDIRNAME];

#else

	extern		HWND				ghMainWnd;
	extern		char				lastURL[MAX_URL_LEN];;
	extern		wchar_t				fullpath[MAXFILENAME + MAXDIRNAME];
	extern		wchar_t				szDefaultLogName[MAXFILENAME];
	extern		wchar_t				RunDirName[MAXDIRNAME];
	extern		wchar_t				gFileName[MAXFILENAME + MAXDIRNAME];
	extern		unsigned int		gControlsList[17];
	extern		VOLATILITY_CMD_TYPEDEF			gCommands[TOT_COMMANDS];
	extern		wchar_t				*gPlatforms[NUM_PLATFORMS];
	extern		wchar_t				gPlatform[10];
	extern		PROCESS_INFORMATION gProcessInfo;
	extern		bool				gCommandRunning;
	//extern		wchar_t				gProfile;
	extern		wchar_t				gKDBG_Addr;

	extern		CRITICAL_SECTION	LogCritSection;

	extern		wchar_t				gStrProgress[100];

	extern		int					gNumScript;
	extern		wchar_t				gScriptFileNames[NUM_SCRIPTS][MAXFILENAME + MAXDIRNAME];

#endif

// Prototypes
	HANDLE SpawnWithRedirect(wchar_t* ProgName, PROCESS_INFORMATION* ProcessInfo, HANDLE *hChildStdOut, HANDLE *hChildStdErr);

#endif //VOLATILITY_WORKBENCH_H